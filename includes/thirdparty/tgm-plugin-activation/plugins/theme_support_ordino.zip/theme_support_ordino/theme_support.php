<?php
/*
Plugin Name: Theme Support
Plugin URI: http://themeforest.net/
Description: This plugin is compatible with this Ordino WordPress themes. 
Author: Mahfuz Rashid
Author URI: http://tonatheme.com
Version: 1.0
Text Domain: BUNCH_NAME
*/
if( !defined( 'BUNCH_TH_ROOT' ) ) define('BUNCH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'BUNCH_TH_URL' ) ) define( 'BUNCH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'BUNCH_NAME' ) ) define( 'BUNCH_NAME', 'ordino' );
include_once( 'includes/loader.php' );

function ordino_bunch_widget_init2()
{
	
	if( class_exists( 'ordino_RecentNews1' ) )register_widget( 'ordino_RecentNews1' );
	if( class_exists( 'ordino_RecentNews2' ) )register_widget( 'ordino_RecentNews2' );
	if( class_exists( 'ordino_AboutUs3' ) )register_widget( 'ordino_AboutUs3' );
	if( class_exists( 'ordino_Subscribeus' ) )register_widget( 'ordino_Subscribeus' );
	if( class_exists( 'ordino_Gallery' ) )register_widget( 'ordino_Gallery' );
	if( class_exists( 'ordino_Twitter' ) )register_widget( 'ordino_Twitter' );
	if( class_exists( 'ordino_Aboutus3' ) )register_widget( 'ordino_Aboutus3' );
	
}
add_action( 'widgets_init', 'ordino_bunch_widget_init2' );